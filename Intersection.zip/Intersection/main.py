''' Given two integer arrays nums1 and nums2, return an array of their intersection.
Each element in the result must appear as many times as it shows in both arrays and
you may return the result in any order.'''

# Input: nums1 = [1,2,2,1], nums2 = [2,2]
# Output: [2,2]

# Input: nums1 = [4,9,5], nums2 = [9,4,9,8,4]
# Output: [4,9] or [9,4]

nums1 = input("Enter the first array: ").split(',')
nums1 = list(map(int, nums1))
nums2 = input("Enter the second array: ").split(',')
nums2 = list(map(int, nums2))
output = []

def intersect(numbers1, numbers2):
    i, j = 0, 0
    numbers1, numbers2 = sorted(numbers1), sorted(numbers2)
    while i < len(numbers1) and j < len(numbers2):
        if numbers1[i] < numbers2[j]:
            i += 1
        elif numbers1[i] > numbers2[j]:
            j += 1
        else:
            output.append(numbers1[i])
            i += 1
            j += 1
    return output

print(intersect(nums1, nums2))

